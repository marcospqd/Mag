import React, { useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileText, Upload, X, Loader2, Link as LinkIcon, Table, Globe, HardDrive, Type, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import * as pdfjs from "pdfjs-dist";
import mammoth from "mammoth";
import pdfjsWorker from "pdfjs-dist/build/pdf.worker.mjs?url";

// Set up PDF.js worker
pdfjs.GlobalWorkerOptions.workerSrc = pdfjsWorker;

export interface Source {
  id: string;
  name: string;
  content: string;
  type: string;
  url?: string;
}

interface SourceManagerProps {
  sources: Source[];
  onSourcesChange: (sources: Source[]) => void;
}

export function SourceManager({ sources, onSourcesChange }: SourceManagerProps) {
  const [isExtracting, setIsExtracting] = useState(false);
  const [sheetUrl, setSheetUrl] = useState("");
  const [pastedText, setPastedText] = useState("");
  const [pastedTitle, setPastedTitle] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const extractTextFromPdf = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjs.getDocument({ data: arrayBuffer }).promise;
    let fullText = "";
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items
        .map((item: any) => item.str)
        .join(" ");
      fullText += pageText + "\n";
    }
    return fullText;
  };

  const extractTextFromDocx = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    return result.value;
  };

  const handleFileUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    setIsExtracting(true);
    const newSources: Source[] = [];

    for (const file of Array.from(files) as File[]) {
      try {
        let content = "";
        const extension = file.name.split('.').pop()?.toLowerCase();

        if (file.type === "application/pdf" || extension === "pdf") {
          content = await extractTextFromPdf(file);
        } else if (extension === "docx") {
          content = await extractTextFromDocx(file);
        } else if (file.type.startsWith("image/")) {
          content = `[Imagem: ${file.name}]`; // Placeholder for OCR or multimodal handling
        } else if (file.type.startsWith("audio/") || file.type.startsWith("video/")) {
          content = `[Arquivo de mídia: ${file.name}]`;
        } else {
          content = await file.text();
        }

        newSources.push({
          id: Math.random().toString(36).substring(7),
          name: file.name,
          content,
          type: extension || "file",
        });
      } catch (error) {
        console.error(`Erro ao processar arquivo ${file.name}:`, error);
      }
    }

    onSourcesChange([...sources, ...newSources]);
    setIsExtracting(false);
    setIsDialogOpen(false);
    event.target.value = ""; 
  }, [sources, onSourcesChange]);

  const handleAddSheet = async () => {
    if (!sheetUrl) return;
    
    setIsExtracting(true);
    try {
      // More flexible regex for Google Sheets URLs
      const match = sheetUrl.match(/[-\w]{25,}/);
      if (!match) {
        throw new Error("URL do Google Sheets inválida. Certifique-se de que o ID da planilha está presente.");
      }
      
      const spreadsheetId = match[0];
      const response = await fetch(`/api/proxy-sheet?spreadsheetId=${spreadsheetId}`);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Falha ao buscar planilha. Verifique se ela é pública.");
      }
      
      const csvText = await response.text();
      
      onSourcesChange([...sources, {
        id: Math.random().toString(36).substring(7),
        name: "Google Sheet",
        content: csvText,
        type: "sheet",
        url: sheetUrl
      }]);
      setSheetUrl("");
      setIsDialogOpen(false);
    } catch (error) {
      console.error("Erro ao adicionar planilha:", error);
      alert(error instanceof Error ? error.message : "Falha ao adicionar Google Sheet");
    } finally {
      setIsExtracting(false);
    }
  };

  const handleAddPastedText = () => {
    if (!pastedText) return;
    
    onSourcesChange([...sources, {
      id: Math.random().toString(36).substring(7),
      name: pastedTitle || "Texto Copiado",
      content: pastedText,
      type: "text"
    }]);
    setPastedText("");
    setPastedTitle("");
    setIsDialogOpen(false);
  };

  const removeSource = (id: string) => {
    onSourcesChange(sources.filter(s => s.id !== id));
  };

  return (
    <Card className="h-full border-none shadow-none bg-zinc-50/50 dark:bg-zinc-900/50 flex flex-col">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4 shrink-0">
        <CardTitle className="text-xl font-semibold flex items-center gap-2">
          <FileText className="w-5 h-5 text-zinc-500" />
          Fontes
        </CardTitle>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger render={
            <Button size="sm" className="rounded-full gap-2">
              <Plus className="w-4 h-4" />
              Adicionar
            </Button>
          } />
          <DialogContent className="sm:max-w-[500px] rounded-3xl">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold text-center mb-4">Adicionar fontes</DialogTitle>
            </DialogHeader>
            
            <div className="grid grid-cols-2 gap-4 py-4">
              <Button
                variant="outline"
                className="h-32 flex flex-col gap-3 rounded-2xl border-zinc-200 hover:bg-zinc-50 hover:border-zinc-300 dark:border-zinc-800 dark:hover:bg-zinc-900"
                onClick={() => document.getElementById("file-upload")?.click()}
              >
                <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-900/20 rounded-full flex items-center justify-center">
                  <Upload className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                </div>
                <span className="font-semibold">Enviar arquivo</span>
              </Button>
              
              <Dialog>
                <DialogTrigger render={
                  <Button
                    variant="outline"
                    className="h-32 flex flex-col gap-3 rounded-2xl border-zinc-200 hover:bg-zinc-50 hover:border-zinc-300 dark:border-zinc-800 dark:hover:bg-zinc-900"
                  >
                    <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-900/20 rounded-full flex items-center justify-center">
                      <Globe className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <span className="font-semibold">Sites</span>
                  </Button>
                } />
                <DialogContent className="rounded-3xl dark:bg-zinc-950 dark:border-zinc-800">
                  <DialogHeader>
                    <DialogTitle>Adicionar link do Google Sheets</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <Input
                      placeholder="Cole a URL da planilha aqui..."
                      value={sheetUrl}
                      onChange={(e) => setSheetUrl(e.target.value)}
                      className="rounded-xl dark:bg-zinc-900 dark:border-zinc-800"
                    />
                    <p className="text-xs text-zinc-500">
                      A planilha deve estar configurada como "Qualquer pessoa com o link pode ler".
                    </p>
                    <Button className="w-full rounded-xl" onClick={handleAddSheet} disabled={isExtracting || !sheetUrl}>
                      {isExtracting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                      Adicionar
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog>
                <DialogTrigger render={
                  <Button
                    variant="outline"
                    className="h-32 flex flex-col gap-3 rounded-2xl border-zinc-200 hover:bg-zinc-50 hover:border-zinc-300 dark:border-zinc-800 dark:hover:bg-zinc-900"
                  >
                    <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-900/20 rounded-full flex items-center justify-center">
                      <Type className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <span className="font-semibold">Texto copiado</span>
                  </Button>
                } />
                <DialogContent className="rounded-3xl sm:max-w-[600px] dark:bg-zinc-950 dark:border-zinc-800">
                  <DialogHeader>
                    <DialogTitle>Colar texto</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <Input
                      placeholder="Título (opcional)"
                      value={pastedTitle}
                      onChange={(e) => setPastedTitle(e.target.value)}
                      className="rounded-xl dark:bg-zinc-900 dark:border-zinc-800"
                    />
                    <textarea
                      placeholder="Cole seu texto aqui..."
                      value={pastedText}
                      onChange={(e) => setPastedText(e.target.value)}
                      className="w-full h-64 p-4 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl focus:ring-2 focus:ring-zinc-900/10 focus:border-zinc-900 outline-none transition-all resize-none text-sm"
                    />
                    <Button className="w-full rounded-xl" onClick={handleAddPastedText} disabled={!pastedText}>
                      Adicionar
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            
            <input
              type="file"
              id="file-upload"
              className="hidden"
              multiple
              accept=".pdf,.txt,.md,.docx,.csv,.pptx,.epub,image/*,audio/*,video/*"
              onChange={handleFileUpload}
              disabled={isExtracting}
            />
            
            <div className="mt-2 text-center">
              <p className="text-[10px] text-zinc-400">
                Tipos suportados: PDF, DOCX, TXT, MD, Imagens, Áudio e mais.
              </p>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col min-h-0">
        <ScrollArea className="flex-1 pr-4">
          {sources.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[300px] text-zinc-400 border-2 border-dashed border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 text-center bg-white/50 dark:bg-zinc-900/50">
              <div className="w-16 h-16 bg-zinc-100 dark:bg-zinc-800 rounded-full flex items-center justify-center mb-4">
                <FileText className="w-8 h-8 opacity-20" />
              </div>
              <p className="text-sm font-bold text-zinc-600 dark:text-zinc-400">Nenhuma fonte adicionada</p>
              <p className="text-xs mt-2 leading-relaxed max-w-[200px]">
                Faça upload de arquivos ou cole links para começar a conversar com seus dados.
              </p>
            </div>
          ) : (
            <div className="space-y-3 pb-4">
              {sources.map(source => (
                <div
                  key={source.id}
                  className="group relative flex items-start gap-3 p-4 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl hover:border-zinc-300 dark:hover:border-zinc-700 transition-all shadow-sm"
                >
                  <div className="p-2.5 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-zinc-500 dark:text-zinc-400 shrink-0">
                    {source.type === "sheet" ? <Table className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-100 truncate">
                        {source.name}
                      </p>
                      {source.url && (
                        <a 
                          href={source.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-zinc-400 hover:text-zinc-600 transition-colors"
                        >
                          <LinkIcon className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                    <p className="text-[10px] text-zinc-500 mt-1 font-medium uppercase tracking-wider">
                      {source.type} • {source.content.length} caracteres
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity shrink-0 rounded-full"
                    onClick={() => removeSource(source.id)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
