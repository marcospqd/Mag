import { useState, useCallback, useRef, useEffect } from "react";
import { ai, LIVE_MODEL } from "../lib/gemini";
import { floatTo16BitPCM, base64EncodeAudio, base64DecodeAudio, pcm16ToFloat32 } from "../lib/audio-utils";
import { Modality } from "@google/genai";

export function useLiveAPI(
  systemInstruction: string, 
  selectedVoice: string = "Zephyr", 
  onMessage?: (role: "user" | "model", text: string) => void,
  tools?: any[],
  onToolCall?: (name: string, args: any) => Promise<any>
) {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isModelSpeaking, setIsModelSpeaking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [volume, setVolume] = useState(0);
  const [userVolume, setUserVolume] = useState(0);
  
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const modelAnalyserRef = useRef<AnalyserNode | null>(null);
  const audioQueueRef = useRef<Float32Array[]>([]);
  const isPlayingRef = useRef(false);
  const silentAudioRef = useRef<HTMLAudioElement | null>(null);

  // Function to calculate volume from PCM data
  const calculateVolume = (data: Float32Array) => {
    let sum = 0;
    for (let i = 0; i < data.length; i++) {
      sum += data[i] * data[i];
    }
    const rms = Math.sqrt(sum / data.length);
    // Apply dampening for smoother animation
    return rms * 0.7;
  };

  const setupMediaSession = useCallback(() => {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: 'Gemini Live Assistant',
        artist: 'Gemini AI',
        album: 'Live Voice Chat',
        artwork: [
          { src: 'https://picsum.photos/seed/gemini/96/96', sizes: '96x96', type: 'image/png' },
          { src: 'https://picsum.photos/seed/gemini/128/128', sizes: '128x128', type: 'image/png' },
          { src: 'https://picsum.photos/seed/gemini/192/192', sizes: '192x192', type: 'image/png' },
          { src: 'https://picsum.photos/seed/gemini/256/256', sizes: '256x256', type: 'image/png' },
          { src: 'https://picsum.photos/seed/gemini/384/384', sizes: '384x384', type: 'image/png' },
          { src: 'https://picsum.photos/seed/gemini/512/512', sizes: '512x512', type: 'image/png' },
        ]
      });

      navigator.mediaSession.setActionHandler('play', () => {
        if (audioContextRef.current?.state === 'suspended') {
          audioContextRef.current.resume();
        }
      });
      navigator.mediaSession.setActionHandler('pause', () => {});
      navigator.mediaSession.setActionHandler('stop', () => disconnect());
    }
  }, []);

  const startSilentAudio = useCallback(() => {
    if (!silentAudioRef.current) {
      // 1 second of silence in WAV format
      const silentWav = "data:audio/wav;base64,UklGRjIAAABXQVZFRm10IBAAAAABAAEAIlYAAESsAAACABAAZGF0YRAAAABAgYGBgYGBgYGBgYGBgYGB";
      const audio = new Audio();
      audio.src = silentWav;
      audio.loop = true;
      silentAudioRef.current = audio;
    }
    
    // Ensure audio is loaded before playing
    silentAudioRef.current.load();
    silentAudioRef.current.play().catch(err => {
      console.warn("Silent audio play failed (expected in some browsers):", err);
    });
    
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'playing';
    }
  }, []);

  const stopSilentAudio = useCallback(() => {
    if (silentAudioRef.current) {
      silentAudioRef.current.pause();
      silentAudioRef.current.currentTime = 0;
    }
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'none';
    }
  }, []);

  const stopAudio = useCallback(() => {
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    audioQueueRef.current = [];
    isPlayingRef.current = false;
    setIsModelSpeaking(false);
  }, []);

  const playNextChunk = useCallback(async () => {
    if (audioQueueRef.current.length === 0 || !audioContextRef.current) {
      isPlayingRef.current = false;
      setIsModelSpeaking(false);
      return;
    }

    if (audioContextRef.current.state === 'suspended') {
      await audioContextRef.current.resume();
    }

    isPlayingRef.current = true;
    setIsModelSpeaking(true);
    const chunk = audioQueueRef.current.shift()!;
    const audioBuffer = audioContextRef.current.createBuffer(1, chunk.length, 24000); // Live API usually outputs 24kHz
    audioBuffer.getChannelData(0).set(chunk);

    if (!modelAnalyserRef.current) {
      modelAnalyserRef.current = audioContextRef.current.createAnalyser();
      modelAnalyserRef.current.fftSize = 256;
      modelAnalyserRef.current.connect(audioContextRef.current.destination);
    }

    const source = audioContextRef.current.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(modelAnalyserRef.current);
    
    // Update model volume for animation
    const updateModelVolume = () => {
      if (!isPlayingRef.current || !modelAnalyserRef.current) {
        setVolume(0);
        return;
      }
      const dataArray = new Uint8Array(modelAnalyserRef.current.frequencyBinCount);
      modelAnalyserRef.current.getByteFrequencyData(dataArray);
      let sum = 0;
      for (let i = 0; i < dataArray.length; i++) {
        sum += dataArray[i];
      }
      // Increased scaling for more visible animation
      const avg = sum / dataArray.length / 320; 
      setVolume(Math.min(avg, 1));
      requestAnimationFrame(updateModelVolume);
    };
    updateModelVolume();

    source.onended = playNextChunk;
    source.start();
  }, []);

  const connect = useCallback(async () => {
    if (isConnected || isConnecting) return;

    setIsConnecting(true);
    setError(null);
    
    // Start silent audio immediately on user gesture to unlock audio
    startSilentAudio();
    
    try {
      const apiKey = import.meta.env.VITE_GEMINI_API_KEY || (typeof process !== 'undefined' ? process.env.GEMINI_API_KEY : "");
      console.log("Connecting to Live API... API Key present:", !!apiKey);
      if (apiKey) {
        console.log("API Key starts with:", apiKey.substring(0, 4) + "...");
      }
      if (!apiKey || apiKey === "API_KEY_NOT_SET") {
        throw new Error("Chave de API não configurada. Por favor, adicione VITE_GEMINI_API_KEY às variáveis de ambiente.");
      }

      // Initialize AudioContext on user gesture
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      }
      
      if (audioContextRef.current.state === 'suspended') {
        await audioContextRef.current.resume();
      }
      
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Seu navegador não suporta acesso ao microfone ou a conexão não é segura (HTTPS).");
      }

      try {
        streamRef.current = await navigator.mediaDevices.getUserMedia({ 
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true
          } 
        });
      } catch (err) {
        if (err instanceof Error && (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError')) {
          throw new Error("Acesso ao microfone negado. Por favor, permita o acesso ao microfone nas configurações do seu navegador para usar o chat por voz.");
        }
        throw err;
      }
      
      const source = audioContextRef.current.createMediaStreamSource(streamRef.current);
      processorRef.current = audioContextRef.current.createScriptProcessor(4096, 1, 1);
      analyserRef.current = audioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 256;
      source.connect(analyserRef.current);

      sessionRef.current = await (ai.live as any).connect({
        model: LIVE_MODEL,
        apiVersion: "v1beta",
        callbacks: {
          onopen: () => {
            setIsConnected(true);
            setIsConnecting(false);
            console.log("Live API connected");
            setupMediaSession();
            
            processorRef.current!.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              
              // Calculate user volume for animation
              setUserVolume(calculateVolume(inputData));

              const pcmData = floatTo16BitPCM(inputData);
              const base64Data = base64EncodeAudio(pcmData);
              
              if (sessionRef.current) {
                sessionRef.current.sendRealtimeInput({
                  audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
                });
              }
            };
            source.connect(processorRef.current!);
            processorRef.current!.connect(audioContextRef.current!.destination);
          },
          onmessage: async (message: any) => {
            // Handle transcriptions
            if (message.serverContent?.modelTurn?.parts) {
              const text = message.serverContent.modelTurn.parts.map((p: any) => p.text).filter(Boolean).join("");
              if (text && onMessage) onMessage("model", text);
            }

            if (message.serverContent?.userTurn?.parts) {
              const text = message.serverContent.userTurn.parts.map((p: any) => p.text).filter(Boolean).join("");
              if (text && onMessage) onMessage("user", text);
            }

            // Handle tool calls
            const toolCalls = message.toolCall?.functionCalls;
            if (toolCalls && onToolCall) {
              const toolResponses = await Promise.all(toolCalls.map(async (call: any) => {
                const response = await onToolCall(call.name, call.args);
                return { name: call.name, response, id: call.id };
              }));
              
              if (sessionRef.current) {
                sessionRef.current.sendToolResponse({ functionResponses: toolResponses });
              }
            }

            // Handle audio output
            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio) {
              const pcmData = base64DecodeAudio(base64Audio);
              const floatData = pcm16ToFloat32(pcmData);
              audioQueueRef.current.push(floatData);
              if (!isPlayingRef.current) playNextChunk();
            }

            // Handle interruption
            if (message.serverContent?.interrupted) {
              audioQueueRef.current = [];
              isPlayingRef.current = false;
              setIsModelSpeaking(false);
            }
          },
          onerror: (error: any) => {
            console.error("Live API error:", error);
            setError(error.message || "A network error occurred while connecting to the Live API.");
            stopSilentAudio();
            disconnect();
          },
          onclose: () => {
            console.log("Live API closed");
            setIsConnected(false);
            stopSilentAudio();
            stopAudio();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: selectedVoice } },
          },
          systemInstruction: systemInstruction,
          tools: tools,
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        },
      });
    } catch (error) {
      console.error("Failed to connect to Live API:", error);
      setError(error instanceof Error ? error.message : "Failed to connect to Live API");
      setIsConnecting(false);
      stopAudio();
    }
  }, [isConnected, isConnecting, systemInstruction, selectedVoice, playNextChunk, stopAudio, tools, onToolCall, setupMediaSession, startSilentAudio]);

  const disconnect = useCallback(() => {
    if (sessionRef.current) {
      try {
        sessionRef.current.close();
      } catch (e) {
        console.warn("Error closing session:", e);
      }
      sessionRef.current = null;
    }
    setIsConnected(false);
    setIsConnecting(false);
    stopAudio();
  }, [stopAudio]);

  const sendMessage = useCallback(async (text: string) => {
    if (!isConnected && !isConnecting) {
      try {
        await connect();
        // The connection might take a moment, so we wait for sessionRef.current
        let attempts = 0;
        while (!sessionRef.current && attempts < 50) {
          await new Promise(resolve => setTimeout(resolve, 100));
          attempts++;
        }
      } catch (err) {
        console.error("Auto-connect failed:", err);
        return;
      }
    }

    if (sessionRef.current) {
      sessionRef.current.sendRealtimeInput({
        text
      });
    }
  }, [isConnected, isConnecting, connect]);

  const sendAudio = useCallback(async (base64Data: string) => {
    if (!isConnected && !isConnecting) {
      try {
        await connect();
        let attempts = 0;
        while (!sessionRef.current && attempts < 50) {
          await new Promise(resolve => setTimeout(resolve, 100));
          attempts++;
        }
      } catch (err) {
        console.error("Auto-connect failed:", err);
        return;
      }
    }

    if (sessionRef.current) {
      sessionRef.current.sendRealtimeInput({
        audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
      });
    }
  }, [isConnected, isConnecting, connect]);

  useEffect(() => {
    const wakeLockRefLocal = { current: null as any };

    const requestLock = async () => {
      if ('wakeLock' in navigator && isConnected) {
        try {
          // Check if permission is granted first if possible
          if ((navigator as any).permissions) {
            const status = await (navigator as any).permissions.query({ name: 'screen-wake-lock' });
            if (status.state === 'denied') {
              console.warn('Wake Lock permission denied by user/browser');
              return;
            }
          }
          wakeLockRefLocal.current = await (navigator as any).wakeLock.request('screen');
          console.log('Wake Lock is active');
        } catch (err) {
          if (err instanceof Error && err.name === 'NotAllowedError') {
            console.warn('Wake Lock disallowed by permissions policy or user');
          } else {
            console.error(`Wake Lock error: ${err}`);
          }
        }
      }
    };

    const handleVisibilityChange = async () => {
      if (wakeLockRefLocal.current !== null && document.visibilityState === 'visible') {
        await requestLock();
      }
    };

    if (isConnected) {
      requestLock();
      document.addEventListener('visibilitychange', handleVisibilityChange);
    }

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (wakeLockRefLocal.current) {
        wakeLockRefLocal.current.release().then(() => {
          wakeLockRefLocal.current = null;
          console.log('Wake Lock released');
        });
      }
    };
  }, [isConnected]);

  useEffect(() => {
    if (isConnected && sessionRef.current) {
      try {
        sessionRef.current.send({
          setup: {
            generationConfig: {
              systemInstruction: { parts: [{ text: systemInstruction }] },
              speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: selectedVoice } } },
              tools: tools
            }
          }
        });
        console.log("Config update sent to Live API");
      } catch (err) {
        console.warn("Could not update Live API config:", err);
      }
    }
  }, [isConnected, systemInstruction, selectedVoice, tools]);

  useEffect(() => {
    return () => {
      disconnect();
    };
  }, [disconnect]);

  return {
    isConnected,
    isConnecting,
    connect,
    disconnect,
    isModelSpeaking,
    error,
    volume,
    userVolume,
    sendMessage,
    sendAudio
  };
}
