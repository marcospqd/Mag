import React, { useState, useMemo, useEffect, useCallback, useRef } from "react";
import { SourceManager, Source } from "./components/SourceManager";
import { useLiveAPI } from "./hooks/useLiveAPI";
import { ai, LIVE_MODEL, TEXT_MODEL } from "./lib/gemini";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Type } from "@google/genai";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Mic, MicOff, Loader2, MessageSquare, Settings, Info, BookOpen, Volume2, Menu, Send, Moon, Sun, Save, Trash2, Radio, Link as LinkIcon, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { floatTo16BitPCM, base64EncodeAudio } from "./lib/audio-utils";

export default function App() {
  const [sources, setSources] = useState<Source[]>(() => {
    const saved = localStorage.getItem("notebook-sources");
    return saved ? JSON.parse(saved) : [];
  });
  const [activeTab, setActiveTab] = useState<"voice" | "settings">("voice");
  const [persona, setPersona] = useState(() => {
    return localStorage.getItem("notebook-persona") || "Um assistente prestativo e profissional.";
  });
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    return (localStorage.getItem("notebook-theme") as "light" | "dark") || "light";
  });
  const [selectedVoice, setSelectedVoice] = useState(() => {
    return localStorage.getItem("notebook-voice") || "Zephyr";
  });
  const [blingState, setBlingState] = useState<{ connected: boolean }>({ connected: false });

  const voices = ["Zephyr", "Puck", "Charon", "Kore", "Fenrir", "Aoede"];

  useEffect(() => {
    const checkBling = async () => {
      try {
        const res = await fetch("/api/bling/status");
        const data = await res.json();
        setBlingState(data);
      } catch (e) {
        console.error("Error checking Bling status", e);
      }
    };
    checkBling();

    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'BLING_AUTH_SUCCESS') {
        setBlingState({ connected: true });
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const handleBlingConnect = async () => {
    try {
      const res = await fetch("/api/auth/bling/url");
      if (!res.ok) {
        let errorMsg = `Status ${res.status}`;
        try {
          const errorData = await res.json();
          errorMsg = errorData.error || errorMsg;
        } catch (e) {
          errorMsg = await res.text() || res.statusText || errorMsg;
        }
        alert(`Erro ao obter URL de conexão: ${errorMsg}`);
        return;
      }
      const data = await res.json();
      if (data.url) {
        window.open(data.url, "bling_oauth", "width=600,height=700");
      } else {
        alert("Erro: URL de autenticação não recebida do servidor.");
      }
    } catch (e) {
      console.error("Error connecting to Bling", e);
      alert("Erro ao conectar com o Bling. Verifique se as variáveis de ambiente (BLING_CLIENT_ID e BLING_CLIENT_SECRET) estão configuradas no Netlify.");
    }
  };

  useEffect(() => {
    localStorage.setItem("notebook-voice", selectedVoice);
  }, [selectedVoice]);

  useEffect(() => {
    localStorage.setItem("notebook-sources", JSON.stringify(sources));
  }, [sources]);

  useEffect(() => {
    localStorage.setItem("notebook-persona", persona);
  }, [persona]);

  useEffect(() => {
    localStorage.setItem("notebook-theme", theme);
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  const toggleTheme = () => setTheme(prev => prev === "light" ? "dark" : "light");

  const blingTools = useMemo(() => [
    {
      functionDeclarations: [
        {
          name: "getBlingOrders",
          description: "Busca os últimos 10 pedidos de venda no Bling ERP.",
          parameters: { type: Type.OBJECT, properties: {}, required: [] }
        },
        {
          name: "getBlingProducts",
          description: "Busca a lista de produtos cadastrados no Bling ERP.",
          parameters: { type: Type.OBJECT, properties: {}, required: [] }
        }
      ]
    }
  ], []);

  const handleToolCall = useCallback(async (name: string, args: any) => {
    console.log("Tool call:", name, args);
    if (name === "getBlingOrders") {
      const res = await fetch("/api/bling/orders");
      return await res.json();
    }
    if (name === "getBlingProducts") {
      const res = await fetch("/api/bling/products");
      return await res.json();
    }
    return { error: "Tool not found" };
  }, []);

  const hasApiKey = useMemo(() => {
    const key = import.meta.env.VITE_GEMINI_API_KEY || (typeof process !== 'undefined' ? process.env.GEMINI_API_KEY : "");
    return !!key;
  }, []);

  const clearSources = () => {
    if (window.confirm("Tem certeza que deseja remover todas as fontes?")) {
      setSources([]);
    }
  };

  const systemInstruction = useMemo(() => {
    const sourceText = sources.map(s => `FONTE: ${s.name}\nCONTEÚDO: ${s.content}`).join("\n\n---\n\n");
    return `
      Identidade e Propósito:
      Você é um assistente de inteligência artificial de alta precisão, operando com a lógica de funcionamento idêntica ao NotebookLM. Sua principal função é ser um analisador de documentos e consultor baseado exclusivamente em fontes.
      
      1. Referência NotebookLM (Grounding Total):
      Seu comportamento deve espelhar o NotebookLM: você é um especialista nas fontes fornecidas abaixo.
      Regra de Ouro: Não use conhecimento externo. Se a resposta não estiver nas fontes, diga explicitamente que não sabe.
      Priorize a precisão factual acima de tudo. Se houver contradição entre as fontes, exponha os diferentes pontos de vista encontrados nos arquivos.
      
      2. Protocolo de Voz Conversacional (Modo Live):
      Diferente do NotebookLM tradicional, você operará em uma conversa por voz contínua e fluida.
      Suas respostas devem ser otimizadas para áudio: evite textos longos, tabelas complexas ou listas extensas, a menos que o usuário peça para detalhar.
      Mantenha um tom natural e humano. Se o usuário te interromper, pare o processamento imediatamente para ouvir a nova instrução.
      
      3. Camada de Personalização (Instruções do Usuário):
      Siga rigorosamente as diretrizes da "Aba de Personalização" fornecida pelo usuário:
      PERSONA/TOM: ${persona}
      
      4. Restrições e Segurança:
      Não tente simular a função "Studio" (geração de podcasts ou resumos pré-gravados). Seu foco é a interação direta em tempo real.
      Em caso de dúvidas sobre termos técnicos presentes nos documentos, explique-os de forma simples e direta.

      5. Integração ERP Bling:
      Você tem acesso aos dados do ERP Bling do usuário. Use as ferramentas 'getBlingOrders' e 'getBlingProducts' para responder perguntas sobre vendas e estoque.
      Sempre verifique os dados antes de afirmar algo sobre o negócio do usuário.
      Se o usuário perguntar "quais foram os últimos pedidos?" ou "quais produtos eu tenho?", use as ferramentas.

      FONTES DISPONÍVEIS:
      ${sources.length > 0 ? sourceText : "Nenhuma fonte carregada ainda. Informe ao usuário que ele precisa carregar documentos para que você possa analisá-los."}
    `;
  }, [sources, persona]);

  const handleLiveMessage = useCallback((role: "user" | "model", text: string) => {
    setMessages(prev => {
      const lastMessage = prev[prev.length - 1];
      
      // If the last message is from the same role and the new text starts with the old text, 
      // it's likely a streaming update. Replace it.
      if (lastMessage && lastMessage.role === role && text.startsWith(lastMessage.text)) {
        const newMessages = [...prev];
        newMessages[newMessages.length - 1] = { ...lastMessage, text };
        return newMessages;
      }
      
      // Avoid exact duplicates
      if (lastMessage && lastMessage.role === role && lastMessage.text === text) {
        return prev;
      }
      
      return [...prev, { role, text, type: "text" }];
    });
  }, []);

  const { 
    isConnected, 
    isConnecting, 
    connect, 
    disconnect, 
    isModelSpeaking, 
    error: apiError, 
    volume,
    userVolume,
    sendMessage, 
    sendAudio
  } = useLiveAPI(systemInstruction, selectedVoice, handleLiveMessage, blingTools, handleToolCall);

  const hasSound = (volume + userVolume) > 0.01;

  const saveToCloud = () => {
    alert("Fontes e configurações salvas localmente com sucesso!");
  };

  const [inputText, setInputText] = useState("");
  const [messages, setMessages] = useState<{ role: "user" | "model", text: string, type: "text" | "audio" }[]>([]);
  const [isGeneratingText, setIsGeneratingText] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const showLiveView = isConnected || (messages.length === 0 && !isGeneratingText);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Auto-disconnect Live mode when typing
  useEffect(() => {
    if (inputText.trim() && isConnected) {
      disconnect();
    }
  }, [inputText, isConnected, disconnect]);

  const [isDictating, setIsDictating] = useState(false);
  const [sttError, setSttError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  const toggleDictation = () => {
    if (isDictating) {
      recognitionRef.current?.stop();
      setIsDictating(false);
      return;
    }

    setSttError(null);
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch (e) {
        console.error(e);
      }
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setSttError("Navegador não suportado");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "pt-BR";
    recognition.continuous = false; // More stable than true
    recognition.interimResults = true;

    recognition.onstart = () => setIsDictating(true);
    recognition.onend = () => setIsDictating(false);
    recognition.onresult = (event: any) => {
      const transcript = Array.from(event.results)
        .map((result: any) => result[0])
        .map((result: any) => result.transcript)
        .join("");
      
      setInputText(transcript);
    };

    recognition.onerror = (event: any) => {
      console.error("Erro no reconhecimento de voz:", event.error);
      setIsDictating(false);
      
      // Map common errors to user-friendly messages
      let message = "Erro: " + event.error;
      if (event.error === 'network') {
        message = "Instabilidade de rede. Tente novamente.";
      } else if (event.error === 'not-allowed') {
        message = "Acesso ao microfone negado.";
      } else if (event.error === 'no-speech') {
        message = "Nenhuma fala detectada.";
      }
      
      setSttError(message);
      setTimeout(() => setSttError(null), 4000);
    };

    try {
      recognition.start();
      recognitionRef.current = recognition;
    } catch (e) {
      console.error(e);
      setIsDictating(false);
    }
  };

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const handleSendMessage = async (customText?: string) => {
    const text = typeof customText === 'string' ? customText : inputText.trim();
    if (!text) return;
    
    // Desativar chat ao vivo se estiver ativo se não for um comando interno
    if (isConnected && !customText) {
      disconnect();
    }

    if (!customText) {
      setMessages(prev => [...prev, { role: "user", text, type: "text" }]);
      setInputText("");
    }
    
    setIsGeneratingText(true);

    try {
      const response = await ai.models.generateContent({
        model: TEXT_MODEL,
        contents: [{ role: "user", parts: [{ text }] }],
        config: {
          systemInstruction: {
            parts: [{ text: systemInstruction }],
          },
        }
      });

      const modelText = response.text;
      if (modelText) {
        setMessages(prev => [...prev, { role: "model", text: modelText, type: "text" }]);
      }
    } catch (err) {
      console.error("Erro ao gerar resposta por texto:", err);
      setMessages(prev => [...prev, { 
        role: "model", 
        text: "Desculpe, ocorreu um erro ao processar sua mensagem por texto. Por favor, tente novamente.", 
        type: "text" 
      }]);
    } finally {
      setIsGeneratingText(false);
    }
  };

  const clearMessages = () => {
    if (window.confirm("Limpar todo o histórico de mensagens?")) {
      setMessages([]);
    }
  };

  const SidebarContent = () => (
    <div className="h-full flex flex-col bg-zinc-50/30">
      <div className="p-6 border-b border-zinc-200 flex items-center gap-3">
        <div className="w-10 h-10 bg-zinc-900 rounded-xl flex items-center justify-center shrink-0">
          <BookOpen className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-lg font-bold tracking-tight">Valores Lev</h1>
          <p className="text-xs text-zinc-500 font-medium uppercase tracking-wider">Assistente Inteligente</p>
        </div>
      </div>
      <div className="flex-1 overflow-hidden">
        <SourceManager sources={sources} onSourcesChange={setSources} />
      </div>
    </div>
  );

  return (
    <div className={cn("flex h-screen font-sans overflow-hidden transition-colors duration-300", theme === "dark" ? "bg-zinc-950 text-zinc-100" : "bg-white text-zinc-900")}>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-[380px] border-r border-zinc-200 dark:border-zinc-800 flex-col shrink-0">
        <SidebarContent />
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col relative min-w-0">
        <header className="h-16 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between px-4 lg:px-8 bg-white/80 dark:bg-zinc-950/80 backdrop-blur-md z-10 shrink-0">
          <div className="flex items-center gap-2 lg:gap-6">
            {/* Mobile Sidebar Trigger */}
            <Sheet>
              <SheetTrigger render={<Button variant="ghost" size="icon" className="lg:hidden" />}>
                <Menu className="w-5 h-5" />
              </SheetTrigger>
              <SheetContent side="left" className="p-0 w-[85%] sm:w-[380px]">
                <SidebarContent />
              </SheetContent>
            </Sheet>

            <Tabs value={activeTab} onValueChange={(v: any) => setActiveTab(v)} className="w-auto">
              <TabsList className="bg-zinc-100/80 dark:bg-zinc-900/80 p-1 h-9">
                <TabsTrigger value="voice" className="gap-2 px-3 lg:px-4 h-7 text-[10px] lg:text-xs font-medium">
                  <Mic className="w-3.5 h-3.5" />
                  <span className="hidden xs:inline">Voz</span>
                </TabsTrigger>
                <TabsTrigger value="settings" className="gap-2 px-3 lg:px-4 h-7 text-[10px] lg:text-xs font-medium">
                  <Settings className="w-3.5 h-3.5" />
                  <span className="hidden xs:inline">Estilo</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={toggleTheme} className="text-zinc-500 dark:text-zinc-400">
              {theme === "light" ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </Button>

            <Button variant="ghost" size="icon" onClick={clearMessages} className="text-zinc-500 dark:text-zinc-400 hover:text-red-500" title="Limpar Chat">
              <Trash2 className="w-5 h-5" />
            </Button>

            <Button variant="ghost" size="icon" onClick={clearSources} className="text-zinc-500 dark:text-zinc-400 hover:text-red-500" title="Limpar Fontes">
              <BookOpen className="w-5 h-5" />
            </Button>
          </div>
        </header>

        <main className="flex-1 relative flex flex-col min-h-0 w-full">
          <AnimatePresence mode="wait">
            {showLiveView ? (
              <motion.div
                key="live-view"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="flex-1 flex flex-col items-center justify-center p-4"
              >
                <div className="relative flex items-center justify-center">
                  {/* Concentric animated rings - Reactive to sound */}
                  <motion.div
                    animate={{ 
                      scale: isConnected && hasSound ? [1, 1 + (volume + userVolume) * 0.4, 1] : 1,
                      opacity: isConnected ? (hasSound ? [0.3, 0.1 + (volume + userVolume) * 0.5, 0.3] : 0.3) : 0.3 
                    }}
                    transition={{ 
                      duration: 0.4, 
                      repeat: isConnected && hasSound ? Infinity : 0, 
                      ease: "easeInOut" 
                    }}
                    className={cn(
                      "absolute w-64 h-64 rounded-full transition-colors duration-500",
                      isConnected ? "bg-emerald-500/20" : "bg-zinc-200/20 dark:bg-zinc-800/20"
                    )}
                  />
                  <motion.div
                    animate={{ 
                      scale: isConnected && hasSound ? [1, 1 + (volume + userVolume) * 0.3, 1] : 1,
                      opacity: isConnected ? (hasSound ? [0.5, 0.2 + (volume + userVolume) * 0.8, 0.5] : 0.5) : 0.5
                    }}
                    transition={{ 
                      duration: 0.3, 
                      repeat: isConnected && hasSound ? Infinity : 0, 
                      ease: "easeInOut",
                      delay: isConnected && hasSound ? 0.1 : 0 
                    }}
                    className={cn(
                      "absolute w-48 h-48 rounded-full transition-colors duration-500",
                      isConnected ? "bg-emerald-500/30" : "bg-zinc-300/30 dark:bg-zinc-700/30"
                    )}
                  />
                  <motion.div
                    animate={{ 
                      scale: isConnected && hasSound ? [1, 1 + (volume + userVolume) * 0.2, 1] : 1,
                      opacity: isConnected ? (hasSound ? [0.8, 0.4 + (volume + userVolume), 0.8] : 0.8) : 0.8
                    }}
                    transition={{ 
                      duration: 0.2, 
                      repeat: isConnected && hasSound ? Infinity : 0, 
                      ease: "easeInOut",
                      delay: isConnected && hasSound ? 0.2 : 0
                    }}
                    className={cn(
                      "absolute w-32 h-32 rounded-full transition-colors duration-500",
                      isConnected ? "bg-emerald-500/40" : "bg-zinc-400/40 dark:bg-zinc-600/40"
                    )}
                  />
                  
                  {/* Central Mic Button */}
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={isConnected ? disconnect : connect}
                    className={cn(
                      "relative z-10 w-24 h-24 rounded-full flex items-center justify-center shadow-2xl transition-all duration-500",
                      isConnected 
                        ? "bg-emerald-500 text-white shadow-emerald-500/40" 
                        : "bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white border border-zinc-200 dark:border-zinc-800"
                    )}
                    style={{
                      scale: isConnected ? 1 + (volume + userVolume) * 0.1 : 1
                    }}
                  >
                    {isConnecting ? (
                      <Loader2 className="w-10 h-10 animate-spin" />
                    ) : isConnected ? (
                      <Mic className="w-10 h-10" />
                    ) : (
                      <Radio className="w-10 h-10" />
                    )}
                  </motion.button>
                </div>
                
                <div className="mt-12 text-center space-y-4">
                  {apiError && (
                    <div className="p-4 bg-red-50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/30 rounded-2xl text-xs text-red-600 dark:text-red-400 max-w-xs mx-auto animate-in fade-in slide-in-from-top-1 space-y-2">
                      <p><strong>Erro:</strong> {apiError}</p>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={connect}
                        className="w-full h-8 rounded-xl border-red-200 hover:bg-red-100 dark:border-red-900 dark:hover:bg-red-900/40 text-[10px]"
                      >
                        Tentar Novamente
                      </Button>
                    </div>
                  )}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="chat-view"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1 flex flex-col min-h-0"
              >
                <ScrollArea className="flex-1 w-full">
                  <div className="max-w-3xl mx-auto p-4 lg:p-8 space-y-6">
                    <div className="space-y-6 pb-12">
                      {messages.map((msg, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className={cn(
                            "flex w-full",
                            msg.role === "user" ? "justify-end" : "justify-start"
                          )}
                        >
                          <div
                            className={cn(
                              "max-w-[85%] rounded-2xl px-4 py-3 text-sm shadow-sm",
                              msg.role === "user"
                                ? "bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900"
                                : "bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-zinc-100"
                            )}
                          >
                            {msg.text}
                          </div>
                        </motion.div>
                      ))}
                      {(isModelSpeaking || isGeneratingText) && (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="flex justify-start"
                        >
                          <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl px-4 py-3 shadow-sm">
                            <div className="flex gap-1 items-center">
                              <span className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                              <span className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                              <span className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-bounce" />
                              {isGeneratingText && <span className="ml-2 text-[10px] text-zinc-400 font-medium uppercase tracking-wider">Digitando...</span>}
                            </div>
                          </div>
                        </motion.div>
                      )}
                      <div ref={messagesEndRef} />
                    </div>
                  </div>
                </ScrollArea>
              </motion.div>
            )}
          </AnimatePresence>

          {activeTab === "settings" && (
            <div className="absolute inset-0 bg-white dark:bg-zinc-950 z-30 overflow-y-auto">
              <div className="max-w-xl mx-auto p-8 space-y-8">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h2 className="text-2xl font-bold tracking-tight">Personalização</h2>
                    <p className="text-sm text-zinc-500">
                      Defina como a IA deve se comportar.
                    </p>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => setActiveTab("voice")}>
                    <Trash2 className="w-5 h-5 rotate-45" /> {/* Using Trash2 rotated as a close icon for now or just Menu */}
                  </Button>
                </div>

                <div className="space-y-4">
                  <label className="text-sm font-semibold text-zinc-700 dark:text-zinc-300">Escolha a Voz</label>
                  <div className="flex flex-wrap gap-2">
                    {voices.map(voice => (
                      <Button
                        key={voice}
                        variant={selectedVoice === voice ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedVoice(voice)}
                        className="rounded-full text-[10px] h-8 px-4 font-bold uppercase tracking-wider transition-all"
                      >
                        <Volume2 className={cn("w-3 h-3 mr-1.5", selectedVoice === voice ? "text-white" : "text-zinc-400")} />
                        {voice}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-sm font-semibold text-zinc-700 dark:text-zinc-300">Integração ERP Bling</label>
                  <p className="text-xs text-zinc-500 mb-2">Conecte seu ERP para perguntar sobre vendas, produtos e estoque.</p>
                  <Button 
                    variant={blingState.connected ? "secondary" : "outline"}
                    className={cn(
                      "w-full h-12 rounded-2xl gap-3 text-sm font-semibold transition-all border-dashed",
                      blingState.connected && "border-emerald-500/50 bg-emerald-500/5 text-emerald-600 dark:text-emerald-400"
                    )}
                    onClick={handleBlingConnect}
                  >
                    {blingState.connected ? (
                      <>
                        <CheckCircle2 className="w-5 h-5" />
                        ERP Bling Conectado
                      </>
                    ) : (
                      <>
                        <LinkIcon className="w-5 h-5" />
                        Conectar Bling ERP
                      </>
                    )}
                  </Button>
                </div>

                <div className="space-y-4">
                  <label className="text-sm font-semibold text-zinc-700 dark:text-zinc-300">Persona / Tom de Voz</label>
                  <textarea
                    className="w-full h-48 p-4 bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl text-sm focus:ring-2 focus:ring-zinc-900/10 focus:border-zinc-900 outline-none transition-all resize-none"
                    placeholder="Ex: Um professor universitário paciente..."
                    value={persona}
                    onChange={(e) => setPersona(e.target.value)}
                  />
                </div>

                <Button onClick={saveToCloud} className="w-full h-12 rounded-2xl gap-2 text-sm font-semibold">
                  <Save className="w-4 h-4" />
                  Salvar Configurações
                </Button>

                <div className="p-4 bg-zinc-100 dark:bg-zinc-900 rounded-2xl flex items-start gap-3">
                  <Info className="w-5 h-5 text-zinc-500 mt-0.5 shrink-0" />
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 leading-relaxed">
                    Essas instruções são combinadas com as regras de grounding para garantir que a IA permaneça fiel às fontes enquanto adota seu estilo preferido.
                  </p>
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Chat Input Area */}
        <div className="p-4 border-t border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950">
          <div className="max-w-3xl mx-auto flex items-center gap-3">
            {/* Live Mode Toggle */}
            <Button
              variant={isConnected ? "default" : "outline"}
              size="icon"
              className={cn(
                "rounded-full shrink-0 h-12 w-12 transition-all duration-300",
                isConnected ? "bg-emerald-500 hover:bg-emerald-600 border-none text-white shadow-lg shadow-emerald-500/20" : "hover:bg-zinc-100 dark:hover:bg-zinc-900"
              )}
              onClick={isConnected ? disconnect : connect}
              disabled={isConnecting}
              title={isConnected ? "Sair do modo Live" : "Entrar no modo Live"}
            >
              {isConnecting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Radio className={cn("w-5 h-5", isConnected && "animate-pulse")} />}
            </Button>

            {/* Message Input Field */}
            <div className="relative flex-1 group">
              <Input
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                placeholder={isDictating ? "Ouvindo..." : "Faça uma pergunta..."}
                className={cn(
                  "pr-24 h-12 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 focus-visible:ring-zinc-900/10 focus-visible:border-zinc-900 transition-all",
                  isDictating && "border-emerald-500 bg-emerald-50/10",
                  sttError && "border-red-500/50 bg-red-50/5"
                )}
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                {sttError && (
                  <span className="text-[10px] text-red-500 font-medium mr-2 animate-pulse whitespace-nowrap">
                    {sttError}
                  </span>
                )}
                {/* Speech to Text (Dictation) */}
                <Button
                  variant="ghost"
                  size="icon"
                  className={cn(
                    "h-8 w-8 rounded-xl transition-all duration-300",
                    isDictating ? "text-emerald-500 bg-emerald-50 dark:bg-emerald-950/30 scale-110 shadow-sm" : "text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100"
                  )}
                  onClick={toggleDictation}
                  title={isDictating ? "Parar de ditar" : "Ditar mensagem"}
                >
                  {isDictating ? (
                    <motion.div
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 1, repeat: Infinity }}
                    >
                      <Mic className="w-4 h-4" />
                    </motion.div>
                  ) : (
                    <Mic className="w-4 h-4" />
                  )}
                </Button>
                
                {/* Send Button */}
                <Button
                  variant="ghost"
                  size="icon"
                  className={cn(
                    "h-8 w-8 rounded-xl transition-colors",
                    inputText.trim() ? "text-zinc-900 dark:text-zinc-100" : "text-zinc-300 dark:text-zinc-700 pointer-events-none"
                  )}
                  onClick={handleSendMessage}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Status */}
        <footer className="h-10 lg:h-12 border-t border-zinc-200 dark:border-zinc-800 px-4 lg:px-8 flex items-center justify-between bg-zinc-50/50 dark:bg-zinc-950/50 text-[8px] lg:text-[10px] font-bold uppercase tracking-widest text-zinc-400 shrink-0">
          <div className="flex items-center gap-3 lg:gap-4">
            <div className="flex items-center gap-1.5">
              <div className={cn("w-1.5 h-1.5 rounded-full", isConnected ? "bg-emerald-500" : "bg-zinc-300")} />
              <span className="hidden xs:inline">{isConnected ? "Conectado" : "Desconectado"}</span>
              <span className="xs:hidden">{isConnected ? "ON" : "OFF"}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className={cn("w-1.5 h-1.5 rounded-full", sources.length > 0 ? "bg-emerald-500" : "bg-zinc-300")} />
              {sources.length} <span className="hidden xs:inline">Fontes</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isConnected && (
              <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-[10px] py-0 h-5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5 animate-pulse" />
                TELA ATIVA
              </Badge>
            )}
            <div className="truncate ml-2">
              Gemini 3.1 Flash Live API
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
