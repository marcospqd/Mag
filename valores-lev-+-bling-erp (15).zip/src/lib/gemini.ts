import { GoogleGenAI } from "@google/genai";

const getApiKey = () => {
  const key = import.meta.env.VITE_GEMINI_API_KEY || (typeof process !== 'undefined' ? process.env.GEMINI_API_KEY : "");
  return key || "";
};

export const ai = new GoogleGenAI({ 
  apiKey: getApiKey() || "API_KEY_NOT_SET",
  apiVersion: "v1beta"
});

export const LIVE_MODEL = "gemini-3.1-flash-live-preview";
export const TEXT_MODEL = "gemini-3-flash-preview";
