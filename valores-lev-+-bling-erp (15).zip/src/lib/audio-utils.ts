/**
 * Converts Float32Array audio data to Int16Array PCM data.
 */
export function floatTo16BitPCM(float32Array: Float32Array): Int16Array {
  const buffer = new Int16Array(float32Array.length);
  for (let i = 0; i < float32Array.length; i++) {
    const s = Math.max(-1, Math.min(1, float32Array[i]));
    buffer[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  return buffer;
}

/**
 * Converts Int16Array PCM data to Float32Array.
 */
export function pcm16ToFloat32(pcmData: Int16Array): Float32Array {
  const float32Array = new Float32Array(pcmData.length);
  for (let i = 0; i < pcmData.length; i++) {
    float32Array[i] = pcmData[i] / 0x8000;
  }
  return float32Array;
}

/**
 * Encodes Int16Array to Base64 string.
 */
export function base64EncodeAudio(buffer: Int16Array): string {
  const uint8Array = new Uint8Array(buffer.buffer);
  let binary = "";
  const len = uint8Array.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(uint8Array[i]);
  }
  return btoa(binary);
}

/**
 * Decodes Base64 string to Int16Array.
 */
export function base64DecodeAudio(base64: string): Int16Array {
  const binary = atob(base64);
  const buffer = new ArrayBuffer(binary.length);
  const uint8Array = new Uint8Array(buffer);
  for (let i = 0; i < binary.length; i++) {
    uint8Array[i] = binary.charCodeAt(i);
  }
  return new Int16Array(buffer);
}
