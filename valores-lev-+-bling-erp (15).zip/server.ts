import express from "express";
import path from "path";
import session from "cookie-session";
import cookieParser from "cookie-parser";
import axios from "axios";

// Environment detection
const isServerless = !!process.env.LAMBDA_TASK_ROOT || !!process.env.NETLIFY || !!process.env.FUNCTIONS_ID || !!process.env.VERCEL || process.env.NODE_ENV === "production";

export function createExpressApp() {
  const app = express();
  
  // Basic logging for debug
  app.use((req, res, next) => {
    if (isServerless) console.log(`${req.method} ${req.path}`);
    next();
  });

  app.use(express.json());
  app.use(cookieParser());
  
  app.use(session({
    name: "bling-assist-session",
    keys: ["bling-assist-key-1", "bling-assist-key-2"],
    maxAge: 7 * 24 * 60 * 60 * 1000,
    secure: isServerless,
    sameSite: isServerless ? "none" : "lax",
    httpOnly: true
  }));

  app.set("trust proxy", 1);

  // Health check for diagnostic
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", serverless: isServerless, time: new Date().toISOString() });
  });

  // Helper to get consistent redirect URI
  const getBlingRedirectUri = (req: express.Request) => {
    const host = req.get("host");
    if (!host) {
      console.warn("Host header missing in request");
    }
    const protocol = (host && host.includes("localhost")) ? "http" : "https";
    const finalHost = host || "localhost:3000";
    return `${protocol}://${finalHost}/auth/bling/callback`;
  };

  // API routes
  app.get("/api/auth/bling/url", (req, res) => {
    try {
      const clientId = process.env.BLING_CLIENT_ID;
      if (!clientId) {
        return res.status(500).json({ error: "BLING_CLIENT_ID not configured in environment" });
      }

      const redirectUri = getBlingRedirectUri(req);
      const state = Math.random().toString(36).substring(7);
      (req.session as any).blingState = state;

      const params = new URLSearchParams({
        response_type: "code",
        client_id: clientId,
        redirect_uri: redirectUri,
        state: state,
        scope: "pedidos.leitura produtos.leitura contatos.leitura"
      });

      const authUrl = `https://www.bling.com.br/Api/v3/oauth/authorize?${params.toString()}`;
      res.json({ url: authUrl });
    } catch (err: any) {
      console.error("URL Generation error:", err);
      res.status(500).json({ error: err.message });
    }
  });

  app.get(["/auth/bling/callback", "/auth/bling/callback/", "/api/auth/bling/callback"], async (req, res) => {
    const { code, state } = req.query;
    const sessionState = (req.session as any).blingState;

    if (!code || state !== sessionState) {
      return res.send("Estado ou código inválido. Por favor, tente novamente.");
    }

    const clientId = process.env.BLING_CLIENT_ID;
    const clientSecret = process.env.BLING_CLIENT_SECRET;

    try {
      const authHeader = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");
      const redirectUri = getBlingRedirectUri(req);

      const response = await axios.post("https://www.bling.com.br/Api/v3/oauth/token", 
        new URLSearchParams({
          grant_type: "authorization_code",
          code: code as string,
          redirect_uri: redirectUri
        }),
        {
          headers: {
            "Authorization": `Basic ${authHeader}`,
            "Content-Type": "application/x-www-form-urlencoded"
          }
        }
      );

      (req.session as any).blingTokens = response.data;
      
      res.send(`
        <html>
          <body>
            <script>
              if (window.opener) {
                window.opener.postMessage({ type: 'BLING_AUTH_SUCCESS' }, '*');
                window.close();
              } else {
                window.location.href = '/';
              }
            </script>
            <p>Conexão com Bling realizada com sucesso! Você já pode fechar esta janela.</p>
          </body>
        </html>
      `);
    } catch (error: any) {
      console.error("Bling OAuth error:", error.response?.data || error.message);
      res.status(500).send("Erro ao autenticar com Bling.");
    }
  });

  app.get("/api/bling/status", (req, res) => {
    res.json({ connected: !!(req.session as any).blingTokens });
  });

  app.get("/api/bling/orders", async (req, res) => {
    const tokens = (req.session as any).blingTokens;
    if (!tokens) return res.status(401).json({ error: "Not connected to Bling" });

    try {
      const response = await axios.get("https://www.bling.com.br/Api/v3/pedidos/vendas", {
        headers: { "Authorization": `Bearer ${tokens.access_token}` },
        params: { limite: 10 }
      });
      res.json(response.data);
    } catch (error: any) {
      res.status(500).json({ error: error.response?.data || error.message });
    }
  });

  app.get("/api/bling/products", async (req, res) => {
    const tokens = (req.session as any).blingTokens;
    if (!tokens) return res.status(401).json({ error: "Not connected to Bling" });

    try {
      const response = await axios.get("https://www.bling.com.br/Api/v3/produtos", {
        headers: { "Authorization": `Bearer ${tokens.access_token}` },
        params: { limite: 10 }
      });
      res.json(response.data);
    } catch (error: any) {
      res.status(500).json({ error: error.response?.data || error.message });
    }
  });

  app.get("/api/proxy-sheet", async (req, res) => {
    const { spreadsheetId } = req.query;
    if (!spreadsheetId || typeof spreadsheetId !== "string") {
      return res.status(400).json({ error: "spreadsheetId is required" });
    }

    try {
      const csvUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/export?format=csv`;
      const response = await fetch(csvUrl);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch sheet: ${response.statusText}`);
      }

      const csvText = await response.text();
      res.send(csvText);
    } catch (error) {
      console.error("Proxy error:", error);
      res.status(500).json({ error: "Failed to fetch Google Sheet. Make sure it is public." });
    }
  });

  // Vite middleware for development
  if (!isServerless && process.env.NODE_ENV !== "production") {
    // Dynamic import to keep Vite out of production bundle
    import("vite").then(({ createServer: createViteServer }) => {
      createViteServer({
        server: { middlewareMode: true },
        appType: "spa",
      }).then(vite => {
        app.use(vite.middlewares);
      });
    }).catch(err => {
      console.warn("Vite failed to load:", err);
    });
  } else {
    // Only serve static files if NOT running as a serverless function
    // Netlify serves the static files automatically from 'dist'
    if (!isServerless) {
      const distPath = path.join(process.cwd(), "dist");
      app.use(express.static(distPath));
      app.get("*", (req, res) => {
        res.sendFile(path.join(distPath, "index.html"));
      });
    }
  }

  // Global Error Handler
  app.use((err: any, req: any, res: any, next: any) => {
    console.error("Express App Error:", err);
    res.status(500).json({ 
      error: "Internal Server Error", 
      message: err.message,
      stack: process.env.NODE_ENV === 'development' ? err.stack : undefined 
    });
  });

  return app;
}

async function startServer() {
  const app = createExpressApp();
  const PORT = 3000;
  
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

// Start only if this file is executed directly (not imported as a function)
if (process.env.NODE_ENV !== 'test' && !isServerless) {
  startServer();
}

